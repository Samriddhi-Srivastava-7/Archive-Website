<section  class=" section light">
<h2>                                                                                                                                                                                                                                                                                                                                                                                                                       
Certificates
</h2>
<p>
    Verify and access certificates published by the organization.
    <p>
<div class ="cards">
    <div class ="card">
<h3>
 Internship Certificates        
</h3>   
<p> Certificate records for completed internships.
</p>
</div>
<div class ="card">
    <h3>
     Experience Certificates   
    </h3>
    <p>
        Experience certificate records issued by the organization.
    </p>
</div>
</div>
</section>