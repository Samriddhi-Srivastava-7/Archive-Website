<section class="section">

  <h2>
    Press Releases
  </h2>

  <p>
    Read official announcements, public statements,
    and organizational updates.
  </p>

  <a href="coming-soon.php" class="btn">
    View Press Releases
  </a>

</section>