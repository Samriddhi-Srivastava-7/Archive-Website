<section class="section">

  <h2>
    Reports
  </h2>

  <p>
    Access annual, financial, and project reports from one place.
  </p>

  <div class="cards">

    <div class="card">

      <h3>
        Annual Reports
      </h3>

      <p>
        Year-wise official organizational reports.
      </p>

    </div>

    <div class="card">

      <h3>
        Financial Reports
      </h3>

      <p>
        Financial documents and summaries.
      </p>

    </div>

    <div class="card">

      <h3>
        Project Reports
      </h3>

      <p>
        Reports related to organizational projects.
      </p>

    </div>

  </div>

</section>