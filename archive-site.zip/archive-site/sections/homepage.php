<section class="home-hero">

    <div class="hero-content">

        <div class="hero-badge">
            Official Archive Site
        </div>

        <h1>
            Archive & Verification Site
        </h1>

        <p>
            Access organizational reports, verify certificates, and explore official public releases from one secure platform.
        </p>

        <div class="hero-actions">
            <a href="/archive-site/pages/verify-certificate.php" class="btn primary-btn">
                Verify Certificate
            </a>

            <a href="#reports" class="btn primary-btn">
                Explore Reports
            </a>
        </div>
    </div>

</section>