<?php include 'includes/header.php'; ?>

<?php include 'sections/homepage.php'; ?>
<?php include 'sections/reports.php'; ?>
<?php include 'sections/certificates.php'; ?>
<?php include 'sections/press.php'; ?>

<?php include 'includes/footer.php'; ?>