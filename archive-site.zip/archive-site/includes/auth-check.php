<?php

require_once "desktop-check.php";

session_start();

if (!isset($_SESSION["admin_logged_in"]) || $_SESSION["admin_logged_in"] !== true) {
    header("Location: ../admin/login.php");
    exit();
}

?>