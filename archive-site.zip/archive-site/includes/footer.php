<footer class="footer">

  <p>
    © 2026 Archive Portal. All rights reserved.
  </p>

</footer>

<script src="/archive-site/assets/js/main.js"></script>

</body>
</html>