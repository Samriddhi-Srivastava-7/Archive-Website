<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Archive</title>

    <link rel="stylesheet" href="/archive-site/assets/css/design.css">

</head>

<body>

<header class="header">

    <!-- LOGO AREA -->

    <div class="logo-wrapper">

        <a href="/archive-site/index.php" class="logo-container">

            <img 
                 src="/archive-site/assets/images/logo-square.png"   
                alt="Rigel Foundation Logo"
                class="site-logo"
            >

            <div class="logo-text">

                <div class="logo">
                    Archive
                </div>

                <div class="logo-subtitle">
                    Rigel Foundation
                </div>

            </div>

        </a>

    </div>

    <!-- NAVBAR -->

    <nav class="nav">

        <a href="/archive-site/index.php">
            Home
        </a>

        <a href="/archive-site/pages/press-release.php">
            Press Release
        </a>

        <!-- REPORTS -->

        <div class="dropdown">

            <a href="#">
                Reports
            </a>

            <ul class="dropdown-menu">

                <li>
                    <a href="/archive-site/pages/annual-reports.php">
                        Annual Reports
                    </a>
                </li>

                <li>
                    <a href="/archive-site/pages/financial-reports.php">
                        Financial Reports
                    </a>
                </li>

                <li>
                    <a href="/archive-site/pages/project-reports.php">
                        Project Reports
                    </a>
                </li>

            </ul>

        </div>

        <!-- CERTIFICATES -->

        <div class="dropdown">

            <a href="#">
                Certificates
            </a>

            <ul class="dropdown-menu">

                <li>
                    <a href="/archive-site/pages/internship-certificates.php">
                        Internship Certificates
                    </a>
                </li>

                <li>
                    <a href="/archive-site/pages/experience-certificates.php">
                        Experience Certificates
                    </a>
                </li>

                <li>
                    <a href="/archive-site/pages/verify-certificate.php">
                        Verify Certificate
                    </a>
                </li>

            </ul>

        </div>

    </nav>

</header>